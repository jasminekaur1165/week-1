public class CaptainAmericaSticker extends Sticker {
	public CaptainAmericaSticker() {
		description = "Captain America Sticker";
	}
 
	public double cost() {
		return .89;
	}
}

