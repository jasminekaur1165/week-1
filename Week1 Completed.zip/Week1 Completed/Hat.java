public class Hat extends AccessoryDecorator {
	public Hat(Sticker sticker) {
		this.sticker = sticker;
		description = (sticker.description + ", wearing hat");
	}

	public String getDescription() {
		return description;
	}

	public double cost() {
		return .50 + sticker.cost();
	}
}
