public class LaptopObserver implements Observer {
	private Sticker sticker;
	private Subject stickerShopSubject;
	
	public LaptopObserver(Subject stickerShopSubject) {
		this.stickerShopSubject = stickerShopSubject;
		stickerShopSubject.registerObserver(this);
	}
	
	public void update(Sticker sticker) {
		this.sticker = sticker;
		display();
	}
	
	public void display() {
		System.out.println("This is Laptop Sticker: " + sticker.getDescription() 
		+ " $" + sticker.cost());
	}
}
