public interface Observer {
	public void update(Sticker sticker);
}
