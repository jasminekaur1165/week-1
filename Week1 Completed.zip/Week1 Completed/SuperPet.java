public class SuperPet extends AccessoryDecorator {
	public SuperPet(Sticker sticker) {
		this.sticker = sticker;
		description = (sticker.description + ", having super pet");
	}
 
	public String getDescription() {
		return description;
	}
 
	public double cost() {
		return 3.10 + sticker.cost();
	}
}
