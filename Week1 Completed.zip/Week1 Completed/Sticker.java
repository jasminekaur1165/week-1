public abstract class Sticker {
	String description = "No accessory";
  
	public String getDescription() {
		return description;
	}
 
	public abstract double cost();
}
