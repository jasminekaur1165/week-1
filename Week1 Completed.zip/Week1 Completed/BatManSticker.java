public class BatManSticker extends Sticker {
	public BatManSticker() {
		description = "BatMan Sticker";
	}
 
	public double cost() {
		return 2.05;
	}
}

