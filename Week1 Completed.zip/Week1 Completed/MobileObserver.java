public class MobileObserver implements Observer {
	private Sticker sticker;
	private Subject stickerShopSubject;
	
	public MobileObserver(Subject stickerShopSubject) {
		this.stickerShopSubject = stickerShopSubject;
		stickerShopSubject.registerObserver(this);
	}
	
	public void update(Sticker sticker) {
		this.sticker = sticker;
		display();
	}
	
	public void display() {
		System.out.println("This is Mobile Sticker: " + sticker.getDescription() 
		+ " $" + sticker.cost());
	}
}
