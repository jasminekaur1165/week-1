public class RocketShoes extends AccessoryDecorator{
	public RocketShoes(Sticker sticker) {
		this.sticker = sticker;
		description = sticker.description + ", wearing rocket shoes";
	}
 
	public String getDescription() {
		return description;
	}
 
	public double cost() {
		return 2.20 + sticker.cost();
	}
}
