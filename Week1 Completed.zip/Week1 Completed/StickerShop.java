public class StickerShop {
 
	public static void main(String args[]) {
		Sticker sticker = new SuperManSticker();
		System.out.println(sticker.getDescription() 
				+ " $" + sticker.cost());
 
		Sticker sticker2 = new IronManSticker();
		sticker2 = new RocketShoes(sticker2);
		sticker2 = new Hat(sticker2);
		sticker2 = new SuperPet(sticker2);
		System.out.println(sticker2.getDescription() 
				+ " $" + sticker2.cost());
 
		Sticker sticker3 = new CaptainAmericaSticker();
		sticker3 = new SuperPet(sticker3);
		sticker3 = new RocketShoes(sticker3);
		System.out.println(sticker3.getDescription() 
				+ " $" + sticker3.cost());
	}
}
