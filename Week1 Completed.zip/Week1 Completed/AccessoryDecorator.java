public abstract class AccessoryDecorator extends Sticker {
	Sticker sticker;
	public abstract String getDescription();
}
