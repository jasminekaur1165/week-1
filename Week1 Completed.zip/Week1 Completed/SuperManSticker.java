public class SuperManSticker extends Sticker {
  
	public SuperManSticker() {
		description = "SuperMan Sticker";;
	}
  
	public double cost() {
		return 1.99;
	}
}

