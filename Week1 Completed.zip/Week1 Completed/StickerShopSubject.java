import java.util.*;

public class StickerShopSubject implements Subject {
	private List<Observer> observers;
	private Sticker sticker;
	
	public StickerShopSubject() {
		observers = new ArrayList<Observer>();
	}
	
	public void registerObserver(Observer o) {
		observers.add(o);
	}
	
	public void removeObserver(Observer o) {
		observers.remove(o);
	}
	
	public void notifyObservers() {
		for (Observer observer : observers) {
			observer.update(sticker);
		}
	}
	
	public void setValue1() {
		Sticker sticker = new SuperManSticker();
				
		this.sticker = sticker; 
 
		
		notifyObservers();
	}

	public void setValue2()
	{
		Sticker sticker2 = new IronManSticker();
		sticker2 = new RocketShoes(sticker2);
		sticker2 = new Hat(sticker2);
		sticker2 = new SuperPet(sticker2);
		this.sticker = sticker2;
		
 
		notifyObservers();
		
	}

	public void setValue3()
	{
		Sticker sticker3 = new CaptainAmericaSticker();
		sticker3 = new SuperPet(sticker3);
		sticker3 = new RocketShoes(sticker3);

		this.sticker = sticker3;
		notifyObservers();
	}


}