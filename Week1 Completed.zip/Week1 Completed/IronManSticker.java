public class IronManSticker extends Sticker {
	public IronManSticker() {
		description = "IronMan Sticker";
	}
 
	public double cost() {
		return 2.99;
	}
}

