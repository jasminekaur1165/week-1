public class MainWeek1Project {

	public static void main(String[] args) {
		StickerShopSubject stickerShopSubject = new StickerShopSubject();
	
		LaptopObserver laptopObserver1 = new LaptopObserver(stickerShopSubject);
		MobileObserver mobileObserver1 = new MobileObserver(stickerShopSubject);

		stickerShopSubject.setValue1();

		stickerShopSubject.setValue2();

		stickerShopSubject.removeObserver(mobileObserver1);

		stickerShopSubject.setValue3();
		
		
	}
}
